records = [
    ('John',  'Smith',   43, 'jsbrony@yahoo.com'),
    ('Ellen', 'James',   32, 'jamestel@google.com'),
    ('Sally', 'Edwards', 36, 'steclone@yahoo.com'),
    ('Keith', 'Cramer',  29, 'kcramer@sintech.com')
]

for idx, contact in enumerate(records):
    print(idx, contact[1])

for contact in reversed(records):
    print(contact[1])

for idx, contact in enumerate(reversed(records)):
    print(idx, contact[1])

fruit = ['Apple', 'Orange', 'Banana', 'Watermelon']
color = ['red', 'orange', 'yellow', 'green', 'blue']

for f, c in zip(fruit, color):
    print(f'The {f} is {c}')