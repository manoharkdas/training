class MyContextManager(object):
    def __enter__(self):
        print('in enter')
        return 'foo'

    def __exit__(self, typ, value, traceback):
        print('in exit')


with MyContextManager() as obj:
    print(obj)
