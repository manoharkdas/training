"""
    task6_1.py  -   Using JSON, Soup, and HTML Parsing

    This task asks you to retrieve the JSON data at the URL provided
    using the requests module.

    You should then parse the data using requests.get(url).json()

    Examine the resulting data structure.  Display the names of each fire.  These
    can be found within a dictionary nested within the overall dictionary.

    Extract the url of the first fire incident.

    Retrieve this page using requests again. This time parse it using BeautifulSoup.
    Display the "zeroeth" <p> tag from this page using find_all().
    Note: Due to the nature of retrieving live data from a web page, its structure
    can change.  As of this writing, the 0th <p> tag was the correct one to obtain.
    If the page structure changes, a browser can be used to determine the correct
    structural item to work with.
"""
import sys

from bs4 import BeautifulSoup
import requests

# import mocklab                # uncomment internet access is not available

page_prefix = 'http://inciweb.nwcg.gov'
page = '/feeds/json/markers/'
fire_data = {}

# -----------------------------------------------------
#   Part I:  Getting the JSON data, displaying fire names
try:
    fire_data = requests.get(page_prefix + page).json()
except requests.RequestException as err:
    print(f'Error requesting data: {err}', file=sys.stderr)

for fire in fire_data.get('markers', []):
    print(fire.get('name', 'No name'))


# ------------------------------------------------------
#   Part II: Description of the first fire
first_fire = fire_data.get('markers', [])[0]
first_fire_url = page_prefix + first_fire.get('url', '')
soup = BeautifulSoup(requests.get(first_fire_url).text, 'html.parser')
print(soup.select('#incidentOverview p')[0].text)
